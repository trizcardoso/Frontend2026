import React, { useState, useEffect } from 'react';

function ContadorContinuo() {
  const [hora, setHora] = useState(new Date().toLocaleTimeString('pt-BR'));

  useEffect(() => {
    const intervalo = setInterval(() => {
      setHora(new Date().toLocaleTimeString('pt-BR'));
    }, 1000);

    return () => clearInterval(intervalo);
  }, []);

  return (
    <h2>{hora}</h2>
  );
}

export default ContadorContinuo;