import React, { useState, useEffect } from 'react';

function Contador() {
  const [contador, setContador] = useState(0);

  useEffect(() => {
    console.log('Componente montado!');
  }, []);

  useEffect(() => {
    document.title = `Contagem> ${contador}`;
    console.log('Componente atualizado ou montado. Novo valor do contador: ', contador);
    return () => {
      console.log("Função de limpeza executada. O contador será removido");
    };
  }, [contador]);

  const incrementar = () => {
    setContador(prevContador => prevContador + 1);
  };
  return(
    <div>
        <h2>Contador Simples</h2>
        <p>O contador está em: {contador}</p>
        <button onClick={incrementar}>Incrementar</button>
    </div>
  );
}

export default Contador;