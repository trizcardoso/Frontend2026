import logo from './logo.svg';
import './App.css';
import Contador from './components/Contador';
import ContadorContinuo from './components/ContadorContinuo';
import './components/style.css'

function App() {
  return (
    <> 
      <div className="App">
        <h1>Minha Aplicação React</h1>
        <Contador />
      </div>
      
      <div id="relogio">
        <h1>Relógio - Contador Contínuo</h1>
        <ContadorContinuo />
      </div>
    </> 
  );
}

export default App;
