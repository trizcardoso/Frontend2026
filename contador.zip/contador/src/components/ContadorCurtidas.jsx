import { useState, useEffect } from "react";
import "../App.css";

function ContadorCurtidas() {
  const [curtidas, setCurtidas] = useState(0);

  useEffect(() => {
    if (curtidas >= 5) {
      alert("Curtidas em alta!");
    }
  }, [curtidas]);

  return (
    <div className="app">
      <div className="contador">
        <h1>Contador de Curtidas</h1>

        <p className="curtidas">
          Curtidas: <span>{curtidas}</span>
        </p>

        <button onClick={() => setCurtidas(curtidas + 1)}>
          Curtir
        </button>

        {curtidas >= 5 && (
          <p className="mensagem">
            Curtidas em alta!
          </p>
        )}
      </div>
    </div>
  );
}

export default ContadorCurtidas;
