import React, { useState } from 'react';
import { Container } from 'react-bootstrap';
import 'bootstrap-icons/font/bootstrap-icons.css';
import Navegacao from './components/Navegacao';
import FormLivro from './components/FormLivro';
import Acervo from './components/Acervo';

export default function App() {
  const [abaAtiva, setAbaAtiva] = useState('cadastro');
  const [livros, setLivros] = useState([]);

  const adicionarLivro = (novoLivro) => {
    setLivros([...livros, novoLivro]);
  };

  return (
    <>
      <Navegacao abaAtiva={abaAtiva} setAbaAtiva={setAbaAtiva} />
      
      <Container fluid="md">
        {abaAtiva === 'cadastro' ? (
          <FormLivro onAdicionarLivro={adicionarLivro} livros={livros} />
        ) : (
          <Acervo livros={livros} />
        )}
      </Container>
    </>
  );
}