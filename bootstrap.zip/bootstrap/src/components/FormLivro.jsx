import React, { useState } from 'react';
import { Row, Col, Form, Button, Table, Card } from 'react-bootstrap';

export default function FormLivro({ onAdicionarLivro, livros }) {
  const [titulo, setTitulo] = useState('');
  const [autor, setAutor] = useState('');
  const [categoria, setCategoria] = useState('');
  const [ano, setAno] = useState('');
  const [erros, setErros] = useState({});

  const validar = () => {
    const novosErros = {};
    const anoAtual = new Date().getFullYear();

    if (!titulo || titulo.trim().length < 3) {
      novosErros.titulo = 'O título deve ter no mínimo 3 caracteres.';
    }

    if (!autor || autor.trim().length < 3) {
      novosErros.autor = 'O autor deve ter no mínimo 3 caracteres.';
    }

    if (!categoria) {
      novosErros.categoria = 'Selecione uma categoria.';
    }

    const anoNum = Number(ano);
    if (!ano || anoNum <= 1900 || anoNum > anoAtual) {
      novosErros.ano = `O ano deve ser maior que 1900 e não pode ser maior que ${anoAtual}.`;
    }

    return novosErros;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errosValidacao = validar();

    if (Object.keys(errosValidacao).length > 0) {
      setErros(errosValidacao);
    } else {
      setErros({});
      onAdicionarLivro({
        id: Date.now(),
        titulo,
        autor,
        categoria,
        ano,
      });

      setTitulo('');
      setAutor('');
      setCategoria('');
      setAno('');
    }
  };

  return (
    <div className="pb-5">
      {/* Card do Formulário */}
      <Card className="shadow-sm border-0 mb-4">
        <Card.Header className="bg-primary text-white py-3">
          <h4 className="mb-0 fs-5 fw-bold">
            <i className="bi bi-pencil-square me-2"></i>Cadastrar Novo Livro
          </h4>
        </Card.Header>
        <Card.Body className="p-4">
          <Form onSubmit={handleSubmit} noValidate>
            <Row className="mb-3">
              <Form.Group as={Col} md={6} controlId="formTitulo" className="mb-3 mb-md-0">
                <Form.Label className="fw-semibold">Título</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Ex: Dom Casmurro"
                  value={titulo}
                  onChange={(e) => setTitulo(e.target.value)}
                  isInvalid={!!erros.titulo}
                />
                <Form.Control.Feedback type="invalid">
                  {erros.titulo}
                </Form.Control.Feedback>
              </Form.Group>

              <Form.Group as={Col} md={6} controlId="formAutor">
                <Form.Label className="fw-semibold">Autor</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Ex: Machado de Assis"
                  value={autor}
                  onChange={(e) => setAutor(e.target.value)}
                  isInvalid={!!erros.autor}
                />
                <Form.Control.Feedback type="invalid">
                  {erros.autor}
                </Form.Control.Feedback>
              </Form.Group>
            </Row>

            <Row className="mb-4">
              <Form.Group as={Col} md={6} controlId="formCategoria" className="mb-3 mb-md-0">
                <Form.Label className="fw-semibold">Categoria</Form.Label>
                <Form.Select
                  value={categoria}
                  onChange={(e) => setCategoria(e.target.value)}
                  isInvalid={!!erros.categoria}
                >
                  <option value="">Selecione uma opção...</option>
                  <option value="Romance">Romance</option>
                  <option value="Técnico">Técnico</option>
                  <option value="Infantil">Infantil</option>
                  <option value="Biografia">Biografia</option>
                </Form.Select>
                <Form.Control.Feedback type="invalid">
                  {erros.categoria}
                </Form.Control.Feedback>
              </Form.Group>

              <Form.Group as={Col} md={6} controlId="formAno">
                <Form.Label className="fw-semibold">Ano de Publicação</Form.Label>
                <Form.Control
                  type="number"
                  placeholder="Ex: 1899"
                  value={ano}
                  onChange={(e) => setAno(e.target.value)}
                  isInvalid={!!erros.ano}
                />
                <Form.Control.Feedback type="invalid">
                  {erros.ano}
                </Form.Control.Feedback>
              </Form.Group>
            </Row>

            <Button variant="primary" type="submit" className="px-4 py-2 fw-bold">
              <i className="bi bi-check-lg me-2"></i>Cadastrar Livro
            </Button>
          </Form>
        </Card.Body>
      </Card>

      {/* Card da Listagem Recente */}
      <Card className="shadow-sm border-0">
        <Card.Header className="bg-light py-3">
          <h5 className="mb-0 text-secondary fw-bold">
            <i className="bi bi-clock-history me-2"></i>Cadastrados Recentemente
          </h5>
        </Card.Header>
        <Card.Body className="p-0">
          {livros.length === 0 ? (
            <p className="text-muted p-4 text-center mb-0">
              Nenhum livro cadastrado até o momento.
            </p>
          ) : (
            <Table responsive striped hover className="align-middle mb-0">
              <thead className="table-light">
                <tr>
                  <th className="ps-4">Título</th>
                  <th>Autor</th>
                </tr>
              </thead>
              <tbody>
                {livros.map((livro) => (
                  <tr key={livro.id}>
                    <td className="ps-4 fw-medium">{livro.titulo}</td>
                    <td>{livro.autor}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card.Body>
      </Card>
    </div>
  );
}