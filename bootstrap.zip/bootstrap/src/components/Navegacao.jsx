import React from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';

export default function Navegacao({ abaAtiva, setAbaAtiva }) {
  return (
    <Navbar bg="dark" variant="dark" expand="lg" className="mb-4 shadow-sm">
      <Container>
        <Navbar.Brand href="#" className="fw-bold fs-4">
          <i className="bi bi-book-half me-2 text-primary"></i>
          BiblioTech
        </Navbar.Brand>
        <Nav className="ms-auto">
          <Nav.Link
            active={abaAtiva === 'cadastro'}
            onClick={() => setAbaAtiva('cadastro')}
            className="px-3"
          >
            <i className="bi bi-plus-circle me-1"></i> Cadastro
          </Nav.Link>
          <Nav.Link
            active={abaAtiva === 'acervo'}
            onClick={() => setAbaAtiva('acervo')}
            className="px-3"
          >
            <i className="bi bi-journal-bookmark me-1"></i> Acervo
          </Nav.Link>
        </Nav>
      </Container>
    </Navbar>
  );
}