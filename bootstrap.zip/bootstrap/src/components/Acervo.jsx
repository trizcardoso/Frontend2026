import React from 'react';
import { Table, Card, Badge } from 'react-bootstrap';

export default function Acervo({ livros }) {
  const getBadgeColor = (cat) => {
    switch (cat) {
      case 'Romance': return 'primary';
      case 'Técnico': return 'dark';
      case 'Infantil': return 'warning';
      case 'Biografia': return 'info';
      default: return 'secondary';
    }
  };

  return (
    <Card className="shadow-sm border-0 mb-5">
      <Card.Header className="bg-secondary text-white py-3">
        <h4 className="mb-0 fs-5 fw-bold">
          <i className="bi bi-collection me-2"></i>Acervo Completo
        </h4>
      </Card.Header>
      <Card.Body className="p-0">
        {livros.length === 0 ? (
          <p className="text-muted p-4 text-center mb-0">
            O acervo está vazio. Cadastre livros na aba "Cadastro".
          </p>
        ) : (
          <Table responsive striped hover className="align-middle mb-0">
            <thead className="table-light">
              <tr>
                <th className="ps-4">Título</th>
                <th>Autor</th>
                <th>Categoria</th>
                <th className="text-end pe-4">Ano</th>
              </tr>
            </thead>
            <tbody>
              {livros.map((livro) => (
                <tr key={livro.id}>
                  <td className="ps-4 fw-bold text-primary">{livro.titulo}</td>
                  <td>{livro.autor}</td>
                  <td>
                    <Badge bg={getBadgeColor(livro.categoria)}>
                      {livro.categoria}
                    </Badge>
                  </td>
                  <td className="text-end pe-4">{livro.ano}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card.Body>
    </Card>
  );
}