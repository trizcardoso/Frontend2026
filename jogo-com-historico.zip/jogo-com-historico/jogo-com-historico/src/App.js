import { useState } from 'react';
import Placar from './components/Placar';
import AcoesJogo from './components/AcoesJogo';
import Historico from './components/Historico';
import ControlesGerais from './components/ControlesGerais';
import './components/style.css';

export default function App() {
  const [pontosA, setPontosA] = useState(0);
  const [pontosB, setPontosB] = useState(0);
  const [posseTimeA, setPosseTimeA] = useState(true);
  const [historico, setHistorico] = useState([]);
  const [historicoPosse, setHistoricoPosse] = useState([]);

  const jogoTerminou = pontosA >= 21 || pontosB >= 21;
  const vencedor = pontosA >= 21 ? 'Time A' : 'Time B';

  function registrarPontos(pontos) {
    if (jogoTerminou) return;

    const timeAtual = posseTimeA ? 'Time A' : 'Time B';

    if (posseTimeA) {
      setPontosA(valor => valor + pontos);
    } else {
      setPontosB(valor => valor + pontos);
    }

    setHistorico(atual => [
      ...atual,
      {
        time: timeAtual,
        pontos,
        texto: `${timeAtual} marcou +${pontos} ponto(s)`
      }
    ]);

    setHistoricoPosse(atual => [...atual, posseTimeA]);
    setPosseTimeA(atual => !atual);
  }

  function passarBola() {
    if (jogoTerminou) return;

    setHistoricoPosse(atual => [...atual, posseTimeA]);

    setHistorico(atual => [
      ...atual,
      {
        time: 'passagem',
        pontos: 0,
        texto: 'Troca de posse de bola'
      }
    ]);

    setPosseTimeA(atual => !atual);
  }

  function desfazerUltimaJogada() {
    if (historico.length === 0) return;

    const novoHistorico = [...historico];
    const ultimaJogada = novoHistorico.pop();

    const novoHistoricoPosse = [...historicoPosse];
    const posseAnterior = novoHistoricoPosse.pop();

    if (ultimaJogada.pontos > 0) {
      if (ultimaJogada.time === 'Time A') {
        setPontosA(valor =>
          Math.max(0, valor - ultimaJogada.pontos)
        );
      }

      if (ultimaJogada.time === 'Time B') {
        setPontosB(valor =>
          Math.max(0, valor - ultimaJogada.pontos)
        );
      }
    }

    setHistorico(novoHistorico);
    setHistoricoPosse(novoHistoricoPosse);

    if (posseAnterior !== undefined) {
      setPosseTimeA(posseAnterior);
    }
  }

  function reiniciarPartida() {
    setPontosA(0);
    setPontosB(0);
    setHistorico([]);
    setHistoricoPosse([]);
    setPosseTimeA(true);
  }

  return (
    <main className="app">
      <header className="cabecalho">
        <div className="titulo-badge">
          <span>●</span> PARTIDA AO VIVO
        </div>

        <h1>Placar do Jogo</h1>

        <p>Acompanhe a partida em tempo real</p>
      </header>

      {jogoTerminou && (
        <div className="vitoria">
          <div className="vitoria-icone">🏆</div>
          <div>
            <small>FIM DE JOGO</small>
            <strong>{vencedor}</strong>
            <span>Venceu o Jogo!</span>
          </div>
        </div>
      )}

      <section className="area-placar">
        <Placar
          pontosA={pontosA}
          pontosB={pontosB}
          posseTimeA={posseTimeA}
        />
      </section>

      <section
        className={`area-acoes ${
          jogoTerminou ? 'jogo-finalizado' : ''
        }`}
      >
        <div className="acoes-titulo">
          <span>AÇÕES DA PARTIDA</span>
          <div></div>
        </div>

        <AcoesJogo
          onPontuar={registrarPontos}
          onPassarBola={passarBola}
        />
      </section>

      <section className="controles">
        <button
          className="botao-desfazer"
          onClick={desfazerUltimaJogada}
          disabled={historico.length === 0}
        >
          <span>↶</span>
          Desfazer Jogada
        </button>

        <ControlesGerais onReiniciar={reiniciarPartida} />
      </section>

      <section className="area-historico">
        <div className="historico-topo">
          <div>
            <span>PARTIDA</span>
            <h2>Histórico</h2>
          </div>

          <div className="contador-jogadas">
            {historico.length} jogadas
          </div>
        </div>

        <Historico
          historico={historico.map(h => h.texto)}
        />
      </section>

      <footer className="rodape">
        Placar do Jogo <span>•</span> Partida em andamento
      </footer>
    </main>
  );
}