import React from 'react';

export default function ControlesGerais({onReiniciar}){
    return(
        <button onClick={onReiniciar}>
            Reiniciar Partida
        </button>
    );
}