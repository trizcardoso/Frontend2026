import { useState } from "react";

export default function FormManutencao({ adicionarManutencao }) {
    const [equipamento, setEquipamento] = useState("");
    const [tipoManutencao, setTipoManutencao] = useState("");
    const [responsavel, setResponsavel] = useState("");
    const [descricao, setDescricao] = useState("");
    const [erros, setErros] = useState({});

    function validar() {
        const novosErros = {};

        if (!equipamento.trim()) {
            novosErros.equipamento = "Informe o equipamento.";
        }

        if (!tipoManutencao) {
            novosErros.tipoManutencao = "Selecione o tipo de manutenção.";
        }

        if (!responsavel.trim()) {
            novosErros.responsavel = "Informe o responsável.";
        }

        if (!descricao.trim()) {
            novosErros.descricao = "Informe a descrição.";
        }

        return novosErros;
    }

    function registrarManutencao(e) {
        e.preventDefault();

        const novosErros = validar();

        setErros(novosErros);

        if (Object.keys(novosErros).length > 0) {
            return;
        }

        const manutencao = {
            equipamento,
            tipoManutencao,
            responsavel,
            descricao
        };

        adicionarManutencao(manutencao);

        setEquipamento("");
        setTipoManutencao("");
        setResponsavel("");
        setDescricao("");
    }

    return (
        <>
            <h2>Registro de Manutenção</h2>

            <form onSubmit={(e) => registrarManutencao(e)}>
                <div className="row">
                    <div className="col-md-6 mb-3">
                        <label htmlFor="equipamento" className="form-label">
                            Equipamento:
                        </label>

                        <input
                            type="text"
                            name="equipamento"
                            id="equipamento"
                            placeholder="Digite o nome do Equipamento"
                            className={`form-control ${erros.equipamento ? "is-invalid" : ""}`}
                            onChange={(e) => setEquipamento(e.target.value)}
                            value={equipamento}
                        />

                        {erros.equipamento && (
                            <div className="invalid-feedback">
                                {erros.equipamento}
                            </div>
                        )}
                    </div>

                    <div className="col-md-6 mb-3">
                        <label htmlFor="tipoManutencao" className="form-label">
                            Tipo de Manutenção:
                        </label>

                        <select
                            name="tipoManutencao"
                            id="tipoManutencao"
                            className={`form-select ${erros.tipoManutencao ? "is-invalid" : ""}`}
                            onChange={(e) => setTipoManutencao(e.target.value)}
                            value={tipoManutencao}
                        >
                            <option value="">Selecione</option>
                            <option value="Preventiva">Preventiva</option>
                            <option value="Corretiva">Corretiva</option>
                            <option value="Preditiva">Preditiva</option>
                        </select>

                        {erros.tipoManutencao && (
                            <div className="invalid-feedback">
                                {erros.tipoManutencao}
                            </div>
                        )}
                    </div>

                    <div className="col-md-6 mb-3">
                        <label htmlFor="responsavel" className="form-label">
                            Responsável:
                        </label>

                        <input
                            type="text"
                            name="responsavel"
                            id="responsavel"
                            placeholder="Digite o nome do Responsável"
                            className={`form-control ${erros.responsavel ? "is-invalid" : ""}`}
                            onChange={(e) => setResponsavel(e.target.value)}
                            value={responsavel}
                        />

                        {erros.responsavel && (
                            <div className="invalid-feedback">
                                {erros.responsavel}
                            </div>
                        )}
                    </div>

                    <div className="col-md-6 mb-3">
                        <label htmlFor="descricao" className="form-label">
                            Descrição:
                        </label>

                        <textarea
                            name="descricao"
                            id="descricao"
                            placeholder="Digite uma descrição..."
                            className={`form-control ${erros.descricao ? "is-invalid" : ""}`}
                            onChange={(e) => setDescricao(e.target.value)}
                            value={descricao}
                        ></textarea>

                        {erros.descricao && (
                            <div className="invalid-feedback">
                                {erros.descricao}
                            </div>
                        )}
                    </div>
                </div>

                <button type="submit" className="btn btn-primary">
                    Enviar
                </button>
            </form>
        </>
    );
}