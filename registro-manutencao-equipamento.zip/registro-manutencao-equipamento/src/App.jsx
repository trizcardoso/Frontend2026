import { useState } from "react";
import FormManutencao from "./components/FormManutencao";

export default function App() {
  const [aba, setAba] = useState("registro");
  const [manutencoes, setManutencoes] = useState([]);

  function adicionarManutencao(manutencao) {
    setManutencoes([...manutencoes, manutencao]);
  }

  return (
    <>
      <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container">
          <a className="navbar-brand">Manutenções</a>

          <div className="navbar-nav">
            <button
              className={`nav-link ${aba === "registro" ? "active" : ""}`}
              onClick={() => setAba("registro")}
            >
              Registro
            </button>

            <button
              className={`nav-link ${aba === "historico" ? "active" : ""}`}
              onClick={() => setAba("historico")}
            >
              Histórico
            </button>
          </div>
        </div>
      </nav>

      <div className="container mt-4">
          {aba === "registro" && (
            <>
              <FormManutencao adicionarManutencao={adicionarManutencao} />

              <h2 className="mt-4">Manutenções registradas</h2>

              {manutencoes.map((manutencao, index) => (
                <div className="card mb-3" key={index}>
                  <div className="card-body">
                    <h5 className="card-title">{manutencao.equipamento}</h5>
                    <p className="card-text">
                      <strong>Tipo:</strong> {manutencao.tipoManutencao}
                    </p>
                    <p className="card-text">
                      <strong>Responsável:</strong> {manutencao.responsavel}
                    </p>
                    <p className="card-text">
                      <strong>Descrição:</strong> {manutencao.descricao}
                    </p>
                  </div>
                </div>
              ))}
            </>
          )}

          {aba === "historico" && (
            <>
              <h2>Histórico</h2>

              <table className="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>Equipamento</th>
                    <th>Tipo</th>
                    <th>Responsável</th>
                    <th>Descrição</th>
                  </tr>
                </thead>

                  <tbody>
                    {manutencoes.map((manutencao, index) => (
                      <tr key={index}>
                        <td>{manutencao.equipamento}</td>
                        <td>
                          {manutencao.tipoManutencao === "Preventiva" && (
                            <span className="badge bg-success">Preventiva</span>
                          )}

                          {manutencao.tipoManutencao === "Corretiva" && (
                            <span className="badge bg-danger">Corretiva</span>
                          )}

                          {manutencao.tipoManutencao === "Preditiva" && (
                            <span className="badge bg-primary">Preditiva</span>
                          )}
                        </td>
                        <td>{manutencao.responsavel}</td>
                        <td>{manutencao.descricao}</td>
                      </tr>
                    ))}
                  </tbody>
              </table>
            </>
          )}
      </div>
    </>
  );
}