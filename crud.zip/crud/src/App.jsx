import React, { useState } from 'react';
import Login from './components/Login';
import Menu from './components/Menu';
import Welcome from './components/Welcome';
import DocenteForm from './components/DocenteForm';
import ListDocentes from './components/ListDocentes';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeScreen, setActiveScreen] = useState('welcome');
  const [docenteToEdit, setDocenteToEdit] = useState(null);

  const [docentes, setDocentes] = useState([
    {
      id: 1,
      nome: 'Adriano',
      cpf: '123.456.789-00',
      formacao: '',
      emailInst: 'adriano@senaisp.edu.br',
      emailPart: 'adriano@gmail.com',
      telefone: '(11) 12345 6789',
      endereco: 'Rua 7 de setembro',
      numero: '100',
      cidade: 'São Paulo',
      cep: '12345-678',
      uf: 'SP'
    }
  ]);

  const handleNavigate = (screen) => {
    setActiveScreen(screen);
  };

  const showCreateForm = () => {
    setDocenteToEdit(null);
    setActiveScreen('form');
  };

  const startEdit = (docente) => {
    setDocenteToEdit(docente);
    setActiveScreen('form');
  };

  const handleSaveDocente = (docenteData) => {
    if (docenteToEdit) {
      setDocentes(
        docentes.map((d) => (d.id === docenteData.id ? docenteData : d))
      );
    } else {
      setDocentes([...docentes, docenteData]);
    }
    setDocenteToEdit(null);
    setActiveScreen('list');
  };

  const handleDeleteDocente = (id) => {
    setDocentes(docentes.filter((d) => d.id !== id));
  };

  return (
    <div className="app-container">
      {!isLoggedIn ? (
        <Login onLogin={() => setIsLoggedIn(true)} />
      ) : (
        <>
          <Menu 
            onNavigate={handleNavigate} 
            onCreate={showCreateForm} 
            onLogout={() => setIsLoggedIn(false)} 
          />
          <main className="content">
            {activeScreen === 'welcome' && <Welcome />}
            {activeScreen === 'list' && (
              <ListDocentes 
                docentes={docentes} 
                onEdit={startEdit} 
                onDelete={handleDeleteDocente} 
              />
            )}
            {activeScreen === 'form' && (
              <DocenteForm 
                docenteToEdit={docenteToEdit} 
                onSave={handleSaveDocente} 
              />
            )}
          </main>
        </>
      )}
    </div>
  );
}

export default App;