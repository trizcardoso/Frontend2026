import React, { useState, useEffect } from 'react';

function DocenteForm({ docenteToEdit, onSave }) {
  const [nome, setNome] = useState('');
  const [cpf, setCpf] = useState('');
  const [formacao, setFormacao] = useState('');
  
  const [emailInst, setEmailInst] = useState('');
  const [emailPart, setEmailPart] = useState('');
  const [telefone, setTelefone] = useState('');
  
  const [endereco, setEndereco] = useState('');
  const [numero, setNumero] = useState('');
  const [cidade, setCidade] = useState('');
  const [cep, setCep] = useState('');
  const [uf, setUf] = useState('');

  const [erros, setErros] = useState({});

  const ufsList = [
    'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA',
    'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN',
    'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'
  ];

  useEffect(() => {
    if (docenteToEdit) {
      setNome(docenteToEdit.nome || '');
      setCpf(docenteToEdit.cpf || '');
      setFormacao(docenteToEdit.formacao || '');
      setEmailInst(docenteToEdit.emailInst || '');
      setEmailPart(docenteToEdit.emailPart || '');
      setTelefone(docenteToEdit.telefone || '');
      setEndereco(docenteToEdit.endereco || '');
      setNumero(docenteToEdit.numero || '');
      setCidade(docenteToEdit.cidade || '');
      setCep(docenteToEdit.cep || '');
      setUf(docenteToEdit.uf || '');
    } else {
      setNome('');
      setCpf('');
      setFormacao('');
      setEmailInst('');
      setEmailPart('');
      setTelefone('');
      setEndereco('');
      setNumero('');
      setCidade('');
      setCep('');
      setUf('');
    }
    setErros({});
  }, [docenteToEdit]);

  const formatarCPF = (v) => v.replace(/\D/g, '').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d{1,2})$/, '$1-$2').slice(0, 14);
  const formatarTelefone = (v) => v.replace(/\D/g, '').replace(/(\d{2})(\d)/, '($1) $2').replace(/(\d{5})(\d)/, '$1-$2').slice(0, 15);
  const formatarCEP = (v) => v.replace(/\D/g, '').replace(/(\d{5})(\d)/, '$1-$2').slice(0, 9);

  const validar = () => {
    const e = {};

    if (!nome || nome.trim().length < 3) e.nome = 'O nome deve conter pelo menos 3 caracteres.';
    if (!cpf || cpf.length < 14) e.cpf = 'CPF obrigatório no formato 000.000.000-00.';
    if (!formacao || formacao.trim() === '') e.formacao = 'Campo obrigatório.';

    if (!emailInst || !emailInst.includes('@')) e.emailInst = 'Email institucional obrigatório e deve conter "@".';
    if (emailPart && !emailPart.includes('@')) e.emailPart = 'Email particular deve conter "@" se preenchido.';
    if (!telefone || telefone.length < 14) e.telefone = 'Telefone celular obrigatório no formato (00) 00000-0000.';

    if (!endereco || endereco.trim() === '') e.endereco = 'Endereço residencial é obrigatório.';
    if (!numero || String(numero).trim() === '') e.numero = 'Número é obrigatório.';
    if (!cidade || cidade.trim() === '') e.cidade = 'Cidade é obrigatória.';
    if (!cep || cep.length < 9) e.cep = 'CEP obrigatório no formato 00000-000.';
    if (!uf) e.uf = 'Selecione um Estado (UF).';

    return e;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errosValidacao = validar();
    if (Object.keys(errosValidacao).length > 0) {
      setErros(errosValidacao);
      return;
    }

    const docenteData = {
      id: docenteToEdit ? docenteToEdit.id : Date.now(),
      nome,
      cpf,
      formacao,
      emailInst,
      emailPart,
      telefone,
      endereco,
      numero,
      cidade,
      cep,
      uf
    };

    onSave(docenteData);
  };

  return (
    <div className="form-container">
      <h2>{docenteToEdit ? 'Alterar Docente' : 'Cadastrar Novo Docente'}</h2>

      <form onSubmit={handleSubmit}>

        <fieldset>
          <legend>Dados Pessoais</legend>
          
          <div className="form-group">
            <label>Nome Completo:</label>
            <input 
              type="text" 
              placeholder="Nome Completo" 
              value={nome} 
              onChange={(e) => setNome(e.target.value)} 
            />
            {erros.nome && <span className="error">{erros.nome}</span>}
          </div>

          <div className="form-group">
            <label>CPF:</label>
            <input 
              type="text" 
              placeholder="000.000.000-00" 
              value={cpf} 
              onChange={(e) => setCpf(formatarCPF(e.target.value))} 
            />
            {erros.cpf && <span className="error">{erros.cpf}</span>}
          </div>

          <div className="form-group">
            <label>Formação/Área de Atuação:</label>
            <input 
              type="text" 
              placeholder="Formação" 
              value={formacao} 
              onChange={(e) => setFormacao(e.target.value)} 
            />
            {erros.formacao && <span className="error">{erros.formacao}</span>}
          </div>
        </fieldset>

        <fieldset>
          <legend>Contatos</legend>

          <div className="form-group">
            <label>Email Institucional:</label>
            <input 
              type="email" 
              placeholder="professor@instituicao.edu.br" 
              value={emailInst} 
              onChange={(e) => setEmailInst(e.target.value)} 
            />
            {erros.emailInst && <span className="error">{erros.emailInst}</span>}
          </div>

          <div className="form-group">
            <label>Email Particular (Opcional):</label>
            <input 
              type="email" 
              placeholder="particular@email.com" 
              value={emailPart} 
              onChange={(e) => setEmailPart(e.target.value)} 
            />
            {erros.emailPart && <span className="error">{erros.emailPart}</span>}
          </div>

          <div className="form-group">
            <label>Telefone Celular:</label>
            <input 
              type="tel" 
              placeholder="(00) 00000-0000" 
              value={telefone} 
              onChange={(e) => setTelefone(formatarTelefone(e.target.value))} 
            />
            {erros.telefone && <span className="error">{erros.telefone}</span>}
          </div>
        </fieldset>

        <fieldset>
          <legend>Endereço</legend>

          <div className="form-group">
            <label>Endereço Residencial:</label>
            <input 
              type="text" 
              placeholder="Rua / Avenida" 
              value={endereco} 
              onChange={(e) => setEndereco(e.target.value)} 
            />
            {erros.endereco && <span className="error">{erros.endereco}</span>}
          </div>

          <div className="form-group">
            <label>Número:</label>
            <input 
              type="text" 
              placeholder="Número" 
              value={numero} 
              onChange={(e) => setNumero(e.target.value)} 
            />
            {erros.numero && <span className="error">{erros.numero}</span>}
          </div>

          <div className="form-group">
            <label>Cidade:</label>
            <input 
              type="text" 
              placeholder="Cidade" 
              value={cidade} 
              onChange={(e) => setCidade(e.target.value)} 
            />
            {erros.cidade && <span className="error">{erros.cidade}</span>}
          </div>

          <div className="form-group">
            <label>CEP:</label>
            <input 
              type="text" 
              placeholder="00000-000" 
              value={cep} 
              onChange={(e) => setCep(formatarCEP(e.target.value))} 
            />
            {erros.cep && <span className="error">{erros.cep}</span>}
          </div>

          <div className="form-group">
            <label>UF (Estado):</label>
            <select value={uf} onChange={(e) => setUf(e.target.value)}>
              <option value="">Selecione a UF</option>
              {ufsList.map((estado) => (
                <option key={estado} value={estado}>{estado}</option>
              ))}
            </select>
            {erros.uf && <span className="error">{erros.uf}</span>}
          </div>
        </fieldset>

        <button type="submit">Salvar</button>
      </form>
    </div>
  );
}

export default DocenteForm;