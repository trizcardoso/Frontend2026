import React from 'react';

function Welcome() {
  return (
    <div className="welcome-container">
      <h2>Bem-vindo ao Sistema de Cadastro de Docentes</h2>
      <p>Utilize o menu superior para navegar entre a listagem de professores e o formulário de cadastro.</p>
    </div>
  );
}

export default Welcome;