import React from 'react';

function Menu({ onNavigate, onCreate, onLogout }) {
  return (
    <nav className="menu-container">
      <button onClick={() => onNavigate('welcome')}>Início</button>
      <button onClick={() => onNavigate('list')}>Listar Docentes</button>
      <button onClick={onCreate}>Cadastrar Docente</button>
      <button onClick={onLogout} className="logout-btn">Sair</button>
    </nav>
  );
}

export default Menu;