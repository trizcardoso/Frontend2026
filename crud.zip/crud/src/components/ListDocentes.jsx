import React from 'react';

function ListDocentes({ docentes, onEdit, onDelete }) {
  return (
    <div className="list-container">
      <h2>Lista de Docentes Cadastrados</h2>
      {docentes.length === 0 ? (
        <p>Nenhum docente cadastrado até o momento.</p>
      ) : (
        <ul className="docente-list">
          {docentes.map((docente) => (
            <li key={docente.id} className="docente-item">
              <div className="docente-info">
                <strong>{docente.nome}</strong>
                <span><strong>Formação:</strong> {docente.formacao}</span>
                <span><strong>Email Inst.:</strong> {docente.emailInst}</span>
                <span><strong>CPF:</strong> {docente.cpf} | <strong>Tel:</strong> {docente.telefone}</span>
                <span><strong>Local:</strong> {docente.cidade}/{docente.uf}</span>
              </div>
              <div className="docente-actions">
                <button className="edit-btn" onClick={() => onEdit(docente)}>
                  Alterar
                </button>
                <button className="delete-btn" onClick={() => onDelete(docente.id)}>
                  Remover
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default ListDocentes;