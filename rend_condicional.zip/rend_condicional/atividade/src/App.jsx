import React from 'react';
import ListaDeTarefas from './components/ListaDeTarefas'; 

function App() {
  const minhasTarefas = ["Estudar", "Fazer exercícios", "Praticar"];
  const listaVazia = [];

  return (
    <div>
      <h2>Tarefas:</h2>
      <ListaDeTarefas tarefas={minhasTarefas} />

      <h2>Tarefas Vazias:</h2>
      <ListaDeTarefas tarefas={listaVazia} />
    </div>
  );
}

export default App;