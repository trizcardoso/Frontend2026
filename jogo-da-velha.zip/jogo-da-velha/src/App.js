import { useState } from 'react';

function Square({ valor, onSquareClick }) {
  const style = {
    width: '70px',
    height: '70px',
    margin: '4px',
    border: 'none',
    borderRadius: '12px',
    backgroundColor: '#ffffff',
    color: valor === 'X' ? '#a174b3' : '#b86c9f',
    fontSize: '32px',
    fontWeight: 'bold',
    cursor: 'pointer',
    boxShadow: '0 4px 10px rgba(0, 0, 0, 0.15)',
    transition: '0.2s',
  };

  return (
    <button style={style} className="square" onClick={onSquareClick}>
      {valor}
    </button>
  );
}

function Tabuleiro({ xIsNext, squares, onPlay }) {
  function handleClick(i) {
    if (squares[i] || calculaVencedor(squares)) {
      return;
    }

    const nextSquares = squares.slice();
    nextSquares[i] = xIsNext ? 'X' : 'O';

    onPlay(nextSquares);
  }

  const vencedor = calculaVencedor(squares);

  let status;

  if (vencedor) {
    status = 'Vencedor: ' + vencedor;
  } else if (squares.every(Boolean)) {
    status = 'Empate!';
  } else {
    status = 'Próximo jogador: ' + (xIsNext ? 'X' : 'O');
  }

  const statusStyle = {
    color: '#ffffff',
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '20px',
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    padding: '12px 24px',
    borderRadius: '12px',
    textAlign: 'center',
  };

  const rowStyle = {
    display: 'flex',
  };

  return (
    <div>
      <div style={statusStyle}>{status}</div>

      <div style={rowStyle}>
        <Square
          valor={squares[0]}
          onSquareClick={() => handleClick(0)}
        />
        <Square
          valor={squares[1]}
          onSquareClick={() => handleClick(1)}
        />
        <Square
          valor={squares[2]}
          onSquareClick={() => handleClick(2)}
        />
      </div>

      <div style={rowStyle}>
        <Square
          valor={squares[3]}
          onSquareClick={() => handleClick(3)}
        />
        <Square
          valor={squares[4]}
          onSquareClick={() => handleClick(4)}
        />
        <Square
          valor={squares[5]}
          onSquareClick={() => handleClick(5)}
        />
      </div>

      <div style={rowStyle}>
        <Square
          valor={squares[6]}
          onSquareClick={() => handleClick(6)}
        />
        <Square
          valor={squares[7]}
          onSquareClick={() => handleClick(7)}
        />
        <Square
          valor={squares[8]}
          onSquareClick={() => handleClick(8)}
        />
      </div>
    </div>
  );
}

export default function Game() {
  const [history, setHistory] = useState([Array(9).fill(null)]);
  const [currentMove, setCurrentMove] = useState(0);

  const xIsNext = currentMove % 2 === 0;
  const currentSquares = history[currentMove];

  function handlePlay(nextSquares) {
    const nextHistory = [
      ...history.slice(0, currentMove + 1),
      nextSquares,
    ];

    setHistory(nextHistory);
    setCurrentMove(nextHistory.length - 1);
  }

  function jumpTo(nextMove) {
    setCurrentMove(nextMove);
  }

  const moves = history.map((squares, move) => {
    let description;

    if (move > 0) {
      description = 'Vai para o movimento #' + move;
    } else {
      description = 'Vai para o início do jogo';
    }

    const buttonStyle = {
      backgroundColor: 'rgba(255, 255, 255, 0.2)',
      border: 'none',
      borderRadius: '6px',
      color: '#ffffff',
      padding: '6px 12px',
      margin: '4px 0',
      cursor: 'pointer',
      fontFamily: 'Arial, sans-serif',
      fontSize: '14px',
      transition: '0.2s',
      width: '180px',
      textAlign: 'left',
    };

    return (
      <li key={move} style={{ listStyleType: 'none' }}>
        <button
          style={buttonStyle}
          onClick={() => jumpTo(move)}
        >
          {description}
        </button>
      </li>
    );
  });

  const gameStyle = {
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'linear-gradient(135deg, #c0b7e0, #68b1ad)',
    fontFamily: 'Arial, sans-serif',
    gap: '40px',
  };

  const infoStyle = {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    padding: '20px',
    borderRadius: '12px',
    maxHeight: '300px',
    overflowY: 'auto',
  };

  return (
    <div style={gameStyle} className="game">
      <div className="game-board">
        <Tabuleiro
          xIsNext={xIsNext}
          squares={currentSquares}
          onPlay={handlePlay}
        />
      </div>

      <div style={infoStyle} className="game-info">
        <ol style={{ padding: 0, margin: 0 }}>
          {moves}
        </ol>
      </div>
    </div>
  );
}

function calculaVencedor(squares) {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];

  for (let i = 0; i < lines.length; i++) {
    const [a, b, c] = lines[i];

    if (
      squares[a] &&
      squares[a] === squares[b] &&
      squares[a] === squares[c]
    ) {
      return squares[a];
    }
  }

  return null;
}