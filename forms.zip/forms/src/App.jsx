import { useState } from 'react'
import FormPesquisa from'./components/FormPesquisa'
import './App.css'

function App() {
  return (
    <Form />
  )
}

export default App
